package com.example.myapplication

import java.util.Date
//Data Modell
data class BitcoinPrice(val date: Date, val price: Double)
